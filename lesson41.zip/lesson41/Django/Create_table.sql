Create Table book
(Id SERIAL PRIMARY KEY,
 title CHARACTER VARYING (60),
 author CHARACTER VARYING (60),
 pyblished_year INTEGER
)