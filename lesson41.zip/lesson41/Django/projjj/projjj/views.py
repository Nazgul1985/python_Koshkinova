from django.shortcuts import render
from .forms import ContactForm
from django.http import HttpResponse
from .models import Book

def show_books(request):
    books = Book.objects.all()
    return render (request,'projjj/books_list.html', {'books': books})



def index(request):
    return render (request,"home.html")

def postuser(request):
     #получаем из данных запроса ПОСТ отправленные через форму данные
     name=request.POST.get("name","Undefined")
     age=request.POST.get("age",1)
     return HttpResponse (f"<h2> Name: {name}  Age {age}</h2>" )

def home_view (request):
     context= {
         'title': 'Главная страница',
         'description': 'Это описание главной страницы',
     }
     return render(request, 'home.html', context)



def contact_view(request):
    if request.method == 'POST':
        form = ContactForm(request.POST)
        if form.is_valid():
            # Обработка данных формы
            name = form.cleaned_data['name']
            email = form.cleaned_data['email']
            message = form.cleaned_data['message']
            # Здесь можно сохранить пользователя в базу данных или выполнить другие действия
            # Например:
            # user = User.objects.create_user(username=username, email=email, password=password)
            # user.save()
            # После успешной обработки формы, вы можете перенаправить пользователя на другую страницу или вернуть сообщение об успешной регистрации
            return render(request, 'registration_success.html', {'name': name})
    else:
        form = ContactForm()
    return render(request, 'contact.html', {'form': form})
