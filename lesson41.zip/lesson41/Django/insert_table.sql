Insert Into book (title, author, pyblished_year)
Values ('Nazgul','Koshkinona', 2024),
	('Ascar', 'Zakenov', 2023),
	('Azamat', 'Alichanov', 2024);